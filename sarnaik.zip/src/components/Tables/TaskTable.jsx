import React, { useState } from "react";
import { Container, Row, Col, Button, Table, Dropdown } from "react-bootstrap";
import { FaEllipsisV } from "react-icons/fa";
import TableHeader from "./TableHeader";
import ProjectTable from "./ProjectTable";


const priorityColors = {
  High: "danger",
  Medium: "warning",
  Low: "primary",
  Normal: "success",
};

const statusColors = {
  Pending: "warning",
  InProgress: "info",
  "On Hold": "danger",
  "To Start": "info",
  Completed: "success",
  Cancelled: "secondary",
};

const initialTasks = [
  {
    id: "T001",
    task: "Design UI for dashboard",
    completedOn: "-",
    startDate: "01-01-2025",
    dueDate: "15-01-2025",
    estimatedTime: "10h",
    hoursLogged: "5h",
    assignedTo: "John Doe",
    priority: "High",
    status: "InProgress",
  },
  {
    id: "T002",
    task: "Develop API endpoints",
    completedOn: "-",
    startDate: "02-01-2025",
    dueDate: "20-01-2025",
    estimatedTime: "15h",
    hoursLogged: "10h",
    assignedTo: "Jane Smith",
    priority: "Medium",
    status: "Pending",
  },
  {
    id: "T003",
    task: "Write test cases",
    completedOn: "-",
    startDate: "05-01-2025",
    dueDate: "25-01-2025",
    estimatedTime: "8h",
    hoursLogged: "2h",
    assignedTo: "Mark Lee",
    priority: "Low",
    status: "To Start",
  },
];

const TaskTable = () => {
  const [tasks, setTasks] = useState(initialTasks);

  const handlePriorityChange = (index, priority) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].priority = priority;
    setTasks(updatedTasks);
  };

  const handleStatusChange = (index, status) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].status = status;
    setTasks(updatedTasks);
  };

  return (

      <Table responsive bordered hover>
        <thead>
          <tr className="table-secondary">
            <th>Task ID</th>
            <th>Task</th>
            <th>Completed On</th>
            <th>Start Date</th>
            <th>Due Date</th>
            <th>Estimated Time</th>
            <th>Hours Logged</th>
            <th>Assigned To</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map((task, index) => (
            <tr key={index}>
              <td>{task.id}</td>
              <td>{task.task}</td>
              <td>{task.completedOn}</td>
              <td>{task.startDate}</td>
              <td>{task.dueDate}</td>
              <td>{task.estimatedTime}</td>
              <td>{task.hoursLogged}</td>
              <td>{task.assignedTo}</td>
              <td>
                <Dropdown onSelect={(eventKey) => handlePriorityChange(index, eventKey)}>
                  <Dropdown.Toggle variant={priorityColors[task.priority]} id="dropdown-priority">
                    {task.priority}
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    {Object.keys(priorityColors).map((priority) => (
                      <Dropdown.Item key={priority} eventKey={priority} className={`text-${priorityColors[priority]}`}>
                        {priority}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </td>
              <td>
                <Dropdown onSelect={(eventKey) => handleStatusChange(index, eventKey)}>
                  <Dropdown.Toggle variant={statusColors[task.status]} id="dropdown-status">
                    {task.status}
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    {Object.keys(statusColors).map((status) => (
                      <Dropdown.Item key={status} eventKey={status} className={`text-${statusColors[status]}`}>
                        {status}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>
              </td>
              <td>
                <Dropdown>
                  <Dropdown.Toggle variant="light" id="dropdown-basic">
                    <FaEllipsisV />
                  </Dropdown.Toggle>
                  <Dropdown.Menu>
                    <Dropdown.Item href="#">Edit</Dropdown.Item>
                    <Dropdown.Item href="#">Delete</Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
 
  );
};

const TaskPage = () => {
  return (
     <div>
       <TableHeader title="All Tasks" buttonText="Add Task" />  
       <ProjectTable />
      </div>
   
  );
};

export default TaskPage;
