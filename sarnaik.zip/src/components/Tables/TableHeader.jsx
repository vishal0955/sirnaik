// import React from 'react';

// const TableHeader = ({ title, buttonText }) => {
//   return (
//     <div className="navbar navbar-expand-lg navbar-light bg-light shadow-sm ">
//       <div className="container-fluid d-flex justify-content-between align-items-center">
//         {/* Left Section: Dynamic Title and Button */}
//         <div className="d-flex align-items-center">
//           <a className="navbar-brand fw-bold text-primary me-3" href="#">{title}</a>
//           <button className="btn btn-primary">{buttonText}</button>
//         </div>

//         {/* Navbar Items */}
//         <div className="collapse navbar-collapse justify-content-center" id="navbarNavDropdown">
//           <ul className="navbar-nav align-items-center gap-3">
//             {/* Filter Dropdown */}
//             <li className="nav-item dropdown">
//               <a className="nav-link dropdown-toggle" href="#" id="filterDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
//                 Filter
//               </a>
//               <ul className="dropdown-menu" aria-labelledby="filterDropdown">
//                 {/* Status Submenu */}
//                 <li className="dropdown-submenu position-relative">
//                   <a className="dropdown-item dropdown-toggle" href="#">By Status</a>
//                   <ul className="dropdown-menu submenu">
//                     <li><a className="dropdown-item" href="#">In Progress</a></li>
//                     <li><a className="dropdown-item" href="#">On Hold</a></li>
//                     <li><a className="dropdown-item" href="#">Cancelled</a></li>
//                     <li><a className="dropdown-item" href="#">Not Started</a></li>
//                     <li><a className="dropdown-item" href="#">Completed</a></li>
//                   </ul>
//                 </li>
//                 {/* Priority Submenu */}
//                 <li className="dropdown-submenu position-relative">
//                   <a className="dropdown-item dropdown-toggle" href="#">By Priority</a>
//                   <ul className="dropdown-menu submenu">
//                     <li><a className="dropdown-item" href="#">High</a></li>
//                     <li><a className="dropdown-item" href="#">Medium</a></li>
//                     <li><a className="dropdown-item" href="#">Low</a></li>
//                     <li><a className="dropdown-item" href="#">No Priority</a></li>
//                   </ul>
//                 </li>
//                 <li><a className="dropdown-item" href="#">By Due Date</a></li>
//                 <li><a className="dropdown-item" href="#">By Assignee</a></li>
//               </ul>
//             </li>

//             {/* Sort Dropdown */}
//             <li className="nav-item dropdown">
//               <a className="nav-link dropdown-toggle" href="#" id="sortDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
//                 Sort
//               </a>
//               <ul className="dropdown-menu" aria-labelledby="sortDropdown">
//                 <li><a className="dropdown-item" href="#">By Name (A-Z)</a></li>
//                 <li><a className="dropdown-item" href="#">By Name (Z-A)</a></li>
//                 <li><a className="dropdown-item" href="#">By Due Date (Earliest First)</a></li>
//                 <li><a className="dropdown-item" href="#">By Due Date (Latest First)</a></li>
//                 <li><a className="dropdown-item" href="#">By Priority (High to Low)</a></li>
//                 <li><a className="dropdown-item" href="#">By Priority (Low to High)</a></li>
//               </ul>
//             </li>

//             {/* Search Bar */}
//             <li className="nav-item d-flex align-items-center">
//               <input type="text" className="form-control me-2" placeholder="Search..." />
//               <button className="btn btn-outline-primary">🔍</button>
//             </li>

//             {/* Export Dropdown */}
//             <li className="nav-item dropdown">
//               <a className="nav-link dropdown-toggle" href="#" id="exportDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
//                 Export
//               </a>
//               <ul className="dropdown-menu" aria-labelledby="exportDropdown">
//                 <li><a className="dropdown-item" href="#">CSV</a></li>
//                 <li><a className="dropdown-item" href="#">Excel</a></li>
//                 <li><a className="dropdown-item" href="#">PDF</a></li>
//               </ul>
//             </li>
//           </ul>
//         </div>

//         {/* Right Section: Add New Button */}
//         <button className="btn btn-success rounded-pill">Add New</button>
//       </div>
//     </div>
//   );
// };

// export default TableHeader;
import React from "react";
import { useNavigate } from "react-router-dom";

const TableHeader = ({ title, buttonText }) => {
    // const [ButtonRoute, setButtonRoute] = useState("");
const navigate = useNavigate();
    const formbutton = (buttonText) => buttonText.toLowerCase().replace(/\s+/g, '');
      
       console.log(formbutton);
   
  return (
    
    <div className="navbar navbar-expand-lg navbar-light bg-light shadow-sm p-3">
      <div className="container-fluid d-flex justify-content-between align-items-center">
        {/* Left Section: Dynamic Title and Button */}
        <div className="d-flex align-items-center">
          <a className="navbar-brand fw-bold text-primary me-3" href="#">
            {title}
          </a>
          <button className="btn btn-primary"  onClick={()=> navigate(`/${formbutton(buttonText)}`)}>{buttonText}</button>
        </div>

        {/* Navbar Items */}
        <div className="collapse navbar-collapse justify-content-center">
          <ul className="navbar-nav align-items-center gap-3">
            {/* Filter Dropdown */}
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" id="filterDropdown" role="button" data-bs-toggle="dropdown">
                Filter
              </a>
              <ul className="dropdown-menu">
                <li className="dropdown-submenu position-relative">
                  <a className="dropdown-item dropdown-toggle" href="#">By Status</a>
                  <ul className="dropdown-menu submenu">
                    <li><a className="dropdown-item" href="#">In Progress</a></li>
                    <li><a className="dropdown-item" href="#">On Hold</a></li>
                    <li><a className="dropdown-item" href="#">Cancelled</a></li>
                    <li><a className="dropdown-item" href="#">Not Started</a></li>
                    <li><a className="dropdown-item" href="#">Completed</a></li>
                  </ul>
                </li>

                <li className="dropdown-submenu position-relative">
                  <a className="dropdown-item dropdown-toggle" href="#">By Priority</a>
                  <ul className="dropdown-menu submenu">
                    <li><a className="dropdown-item" href="#">High</a></li>
                    <li><a className="dropdown-item" href="#">Medium</a></li>
                    <li><a className="dropdown-item" href="#">Low</a></li>
                    <li><a className="dropdown-item" href="#">No Priority</a></li>
                  </ul>
                </li>

                <li><a className="dropdown-item" href="#">By Due Date</a></li>
                <li><a className="dropdown-item" href="#">By Assignee</a></li>
              </ul>
            </li>

            {/* Sort Dropdown */}
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" id="sortDropdown" role="button" data-bs-toggle="dropdown">
                Sort
              </a>
              <ul className="dropdown-menu">
                <li><a className="dropdown-item" href="#">By Name (A-Z)</a></li>
                <li><a className="dropdown-item" href="#">By Name (Z-A)</a></li>
                <li><a className="dropdown-item" href="#">By Due Date (Earliest First)</a></li>
                <li><a className="dropdown-item" href="#">By Due Date (Latest First)</a></li>
                <li><a className="dropdown-item" href="#">By Priority (High to Low)</a></li>
                <li><a className="dropdown-item" href="#">By Priority (Low to High)</a></li>
              </ul>
            </li>

            {/* Search Bar */}
            <li className="nav-item d-flex align-items-center">
              <input type="text" className="form-control me-2" placeholder="Search..." />
              <button className="btn btn-outline-primary">🔍</button>
            </li>

            {/* Export Dropdown */}
            <li className="nav-item dropdown">
              <a className="nav-link dropdown-toggle" href="#" id="exportDropdown" role="button" data-bs-toggle="dropdown">
                Export
              </a>
              <ul className="dropdown-menu">
                <li><a className="dropdown-item" href="#">CSV</a></li>
                <li><a className="dropdown-item" href="#">Excel</a></li>
                <li><a className="dropdown-item" href="#">PDF</a></li>
              </ul>
            </li>
          </ul>
        </div>

        {/* Right Section: Add New Button */}
        <button className="btn btn-success rounded-pill">{buttonText}</button>
      </div>
    </div>
  );
};

export default TableHeader;
