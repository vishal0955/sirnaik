import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "./Sidebar.css";

const Sidebar = ({ collapsed , menuItemClick, onEMRClick }) => {
  const [openSubmenu, setOpenSubmenu] = useState(null); // Tracks the open submenu
  const navigate = useNavigate();
  const location = useLocation();

  const toggleSubmenu = (menuName) => {
    setOpenSubmenu((prev) => (prev === menuName ? null : menuName));
  };

   // Function to check if a path is active
   const isActive = (path) => {
    return location.pathname === path;
  };

    // Function to check if any of the subm enu items are active
    const isSubmenuActive = (paths) => {
      return paths.some((path) => location.pathname.startsWith(path));
    };

  return (
    <div className={`sidebar-container ${collapsed ? "collapsed" : ""}`}>
      <div className="sidebar">
        <ul className="menu">
          {/* Dashboard Section */}
          <li className={`menu-item ${isActive("/dashboard") ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => {navigate("/dashboard"); menuItemClick();} } >
              <i className="fa-solid fa-cubes"></i>
              <span className="menu-text">Dashboard</span>
            </div>
          </li>

          <li className={`menu-item ${isActive("/projects") ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => {navigate("/Project"); menuItemClick();} } >
              <i className="fa-solid fa-cubes"></i>
              <span className="menu-text">Project </span>
            </div>
          </li>

          
          <li className={`menu-item ${isActive("/tasktable") ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => {navigate("/tasktable"); menuItemClick();} } >
              <i className="fa-solid fa-cubes"></i>
              <span className="menu-text">Tasks</span>
            </div>
          </li>

 

          {/* Patient Management Section */}
          <li className={`menu-item ${isSubmenuActive(["/registration", "/patientprofiles","/appointmentscheduling","/patienthistory","/billingpayments"]) ? "active" : ""}`}>
            <div className="menu-link menu-i" onClick={() => toggleSubmenu("registration")}>
              <i className="fa-solid fa-list-check"></i>
              <span className="menu-text">Project Manager</span>
              <i className={`fa-solid fa-chevron-down submenu-arrow ${openSubmenu === "Registration" ? "rotated" : ""}`}></i>
            </div>
          </li>
          <ul className={`submenu ${openSubmenu === "registration" ? "expanded" : "collapsed"}`}>
            <li className={`submenu-item ${isActive("/registration") ? "active" : ""}`}
              onClick={() => {navigate("/registration");setOpenSubmenu(null);menuItemClick();}}>
              <i className="fa-solid fa-arrow-trend-up"></i> Registration
            </li>
            <li className={`submenu-item ${isActive("/patientprofiles") ? "active" : ""}`}
              onClick={() => {
                navigate("/patientprofiles");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Patient Profiles
            </li>
            <li className={`submenu-item ${isActive("/appointmentscheduling") ? "active" : ""}`}
              onClick={() => {
                navigate("/appointmentscheduling");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Appointment Scheduling
            </li>
            <li className={`submenu-item ${isActive("/Patient History") ? "active" : ""}`}
              onClick={() => {
                navigate("/patienthistory");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Patient History
            </li>
            <li className={`submenu-item ${isActive("/billingpayments") ? "active" : ""}`}
              onClick={() => {
                navigate("/billingpayments");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Billing & Payments
            </li>
          </ul>
          {/* Doctor and Staff Management Section */}
          {/* <li className={`menu-item ${isSubmenuActive(["/doctorprofiles", "/Staff Scheduling","/Payroll"]) ? "active" : ""}`}>
            <div className="menu-link menu-i" onClick={() => toggleSubmenu("doctorprofiles")}>
              <i className="fa-solid fa-list-check"></i>
              <span className="menu-text">Doctor and Staff
              Management</span>
              <i className={`fa-solid fa-chevron-down submenu-arrow ${openSubmenu === "doctorprofiles" ? "rotated" : ""}`}></i>
            </div>
          </li>
          <ul className={`submenu ${openSubmenu === "doctorprofiles" ? "expanded" : "collapsed"}`}>
            <li className={`submenu-item ${isActive("/doctorprofilesDoctor Profiles") ? "active" : ""}`}
              onClick={() => {navigate("/doctorprofiles");setOpenSubmenu(null);menuItemClick();}}>
              <i className="fa-solid fa-arrow-trend-up"></i> Doctor Profiles
            </li>
            <li className={`submenu-item ${isActive("/Staff Scheduling") ? "active" : ""}`}
              onClick={() => {
                navigate("/Staff Scheduling");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Staff Scheduling
            </li>
            <li className={`submenu-item ${isActive("/Payroll") ? "active" : ""}`}
              onClick={() => {
                navigate("/Payroll");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Payroll
            </li>
          </ul> */}

          {/* Clinical Management Section */}
          {/* <li className={`menu-item ${isSubmenuActive(["/emr","/outpatient","/Inpatient","/Emergency Department"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("emr")}>
              <i className="fa-solid fa-arrow-trend-up"></i>
              <span className="menu-text">Clinical Management </span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "emr" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "emr" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/emr") ? "active" : ""
              }`}
              onClick={() => {
                onEMRClick();
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> EMR
            </li>
            <li
              className={`submenu-item ${
                isActive("/outpatient") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/outpatient");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Outpatient (OPD)
            </li>
            <li
              className={`submenu-item ${
                isActive("/serviceswo") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/serviceswo");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Inpatient (IPD)
            </li>
            <li
              className={`submenu-item ${
                isActive("/honoring") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/honoring");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Emergency Department
              </li>
          </ul> */}

          {/* Laboratory and Diagnostic Management Section */}
          {/* <li className={`menu-item ${isSubmenuActive(["/testrequests","/resultsintegration","/inventorymanagement"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("testrequests")}>
              <i className="fa-solid fa-arrow-trend-up"></i>
              <span className="menu-text">Laboratory and Diagnostic </span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "testrequests" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "testrequests" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/testrequests") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/testrequests");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Test Requests
            </li>
            <li
              className={`submenu-item ${
                isActive("/resultsintegration") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/resultsintegration");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Results Integration
            </li>
            <li
              className={`submenu-item ${
                isActive("/inventorymanagement") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/inventorymanagement");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Inventory Management
            </li>
          </ul> */}

          {/* Pharmacy Managements Section */}

          {/* <li className={`menu-item ${isSubmenuActive(["/inventorycontrol","/prescriptionmanagement","/billingintegration"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("inventorycontrol")}>
              <i className="fa-solid fa-arrow-trend-up"></i>
              <span className="menu-text">Pharmacy Managements </span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "inventorycontrol" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "inventorycontrol" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/inventorycontrol") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/inventorycontrol");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Inventory Control
            </li>
            <li
              className={`submenu-item ${
                isActive("/prescriptionmanagement") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/prescriptionmanagement");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Prescription Management
            </li>
            <li
              className={`submenu-item ${
                isActive("/billingintegration") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/billingintegration");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Billing Integration
            </li>
          </ul> */}
          {/* Pharmacy Managements Section */}

          {/* Financial Management Section */}
          {/* <li className={`menu-item ${isSubmenuActive(["/revenuedashboard","/claimsmanagement","/invoicehistory"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("revenuedashboard")}>
              <i className="fa-solid fa-arrow-trend-up"></i>
              <span className="menu-text">Financial Management</span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "revenuedashboard" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "revenuedashboard" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/revenuedashboard") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/revenuedashboard");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Revenue Dashboard
            </li>
            <li
              className={`submenu-item ${
                isActive("/claimsmanagement") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/claimsmanagement");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Claims Management
            </li>
            <li
              className={`submenu-item ${
                isActive("/invoicehistory") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/invoicehistory");
                setOpenSubmenu(null); menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Invoice History
            </li>
          </ul> */}
          {/* Financial Management Section */}

          {/* Inventory & Procurement Section */}

          {/* <li className={`menu-item ${isSubmenuActive(["/procurementdashboard","/inventorytracking"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("procurementdashboard")}>
              <i className="fa-solid fa-file-contract"></i>
              <span className="menu-text">Inventory & Procurement</span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "procurementdashboard" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "procurementdashboard" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/procurementdashboard") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/procurementdashboard");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Procurement Dashboard
            </li>
            <li
              className={`submenu-item ${
                isActive("/inventorytracking") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/inventorytracking");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i>Inventory Tracking
            </li>
          </ul> */}
          {/* Inventory & Procurement Section */}

          {/* Administrative Management Section */}
          <li className={`menu-item ${isSubmenuActive(["/hrandpayroll","/facilitymanagement","/compliancetracking"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("hrandpayroll")}>
              <i className="fa-solid fa-file-contract"></i>
              <span className="menu-text">Administrative Management</span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "hrandpayroll" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "hrandpayroll" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/hrandpayroll") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/hrandpayroll");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> HR and Payroll
            </li>
            <li
              className={`submenu-item ${
                isActive("/facilitymanagement") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/facilitymanagement");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Facility Management
            </li>
            <li
              className={`submenu-item ${
                isActive("/compliancetracking") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/compliancetracking");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Compliance Tracking
            </li>
          </ul>
          {/* Administrative Management Section */}

          {/* Reporting & Analytics Section */}
          <li className={`menu-item ${isSubmenuActive(["/realtimedashboard","/Custom Reports","/Predictive Analytics"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("realtimedashboard")}>
              <i className="fa-solid fa-file-contract"></i>
              <span className="menu-text">Reporting & Analytics</span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "realtimedashboard" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "realtimedashboard" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/realtimedashboard") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/realtimedashboard");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Real-Time Dashboard
            </li>
            <li
              className={`submenu-item ${
                isActive("/Custom Reports") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/Custom Reports");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Custom Reports
            </li>
            <li
              className={`submenu-item ${
                isActive("/Predictive Analytics") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/Predictive Analytics");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Predictive Analytics
            </li>
          </ul>
          {/* Reporting & Analytics Section */}

          {/* Communication & Telemedicine */}
          <li className={`menu-item ${isSubmenuActive(["/patientcommunication","/telemedicine","/centermanagement"]) ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => toggleSubmenu("patientcommunication")}>
              <i className="fa-solid fa-arrow-trend-up"></i>
              <span className="menu-text">Communication & Telemedicine</span>
              <i
                className={`fa-solid fa-chevron-down submenu-arrow ${
                  openSubmenu === "patientcommunication" ? "rotated" : ""
                }`}></i>
            </div>
          </li>
          <ul
            className={`submenu ${
              openSubmenu === "patientcommunication" ? "expanded" : "collapsed"
            }`}>
            <li
              className={`submenu-item ${
                isActive("/patientcommunication") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/patientcommunication");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Patient Communication
            </li>
            <li
              className={`submenu-item ${
                isActive("/telemedicine") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/telemedicine");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Telemedicine
            </li>
            <li
              className={`submenu-item ${
                isActive("/centermanagement") ? "active" : ""
              }`}
              onClick={() => {
                navigate("/centermanagement");
                setOpenSubmenu(null);menuItemClick();
              }}>
              <i className="fa-solid fa-arrow-trend-up"></i> Call Center Management
            </li>
            </ul>
          {/* Communication & Telemedicine */}
          {/* Add category and Sub Category */}
          <li
            className={`menu-item ${isActive("/Settings") ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => {navigate("/Settings");menuItemClick();}}>
              <i className="fa-solid fa-chart-line"></i>
              <span className="menu-text">Settings</span>
            </div>
          </li>
          {/* Add category and Sub Category */}
          <li
            className={`menu-item ${isActive("/Log out") ? "active" : ""}`}>
            <div
              className="menu-link menu-i"
              onClick={() => {navigate("/Log out");menuItemClick();}}>
              <i className="fa-solid fa-chart-line"></i>
              <span className="menu-text">Log out</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
