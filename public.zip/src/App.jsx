import { Route, Routes, useLocation } from "react-router-dom";
import "./App.css";
import { useState } from "react";
import Navbar from "./layout/Navbar";
import Sidebar from "./layout/Sidebar";
import Login from "./authtication/Login";

 

import ProjectOwner from "./components/Tables/ProjectOwner";
import TaskPage from "./components/Tables/TaskTable";
import AddProject from "./components/Forms/AddProject";
import TaskForm from "./components/Forms/AddTask";
import DashBoard from "./components/DashBoard";

function App() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isClinicSidebarOpen, setIsClinicSidebarOpen] = useState(false);
  const menusidebarcollaps = () => {
    setIsSidebarCollapsed(true);
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => !prev);
  };
  // Open ClinicManageSidebar (on EMR menu click)
  const openClinicSidebar = () => {
    setIsClinicSidebarOpen(true);
  };
  // Back button in ClinicManageSidebar to show the main sidebar again
  const closeClinicSidebar = () => {
    setIsClinicSidebarOpen(false);
  };
  const location = useLocation();

  const hideLayout = location.pathname === "/";
  // console.log("-----------------",isClinicSidebarOpen)
  return (
    <>
      {/* navbar */}
      {!hideLayout && (
        <Navbar toggleSidebar={toggleSidebar} onBack={closeClinicSidebar} />
      )}
      {/* navbar end */}
      {/* sidebar start */}
      <div className={`main-content  ${hideLayout ? "" : ""}`}>
        {!hideLayout &&
          (isClinicSidebarOpen ? (
            <>
              <ClinicManageSidebar
                collapsed={isSidebarCollapsed}
                menuItemClick={menusidebarcollaps}
                onBack={closeClinicSidebar} // Back button click event
              />
            </> 
          ) : (
            <Sidebar
              collapsed={isSidebarCollapsed}
              menuItemClick={menusidebarcollaps}
              onEMRClick={openClinicSidebar} // Open ClinicManageSidebar on EMR click
            />
          ))}
        {/* sidebar end */}
        {/* right side  */}
        <div
          className={`right-side-content ${
            isSidebarCollapsed ? "collapsed " : ""
          }`}>
          <Routes>
            {/* login signup */}
            <Route path="/" element={<Login />} />
            <Route path="/dashboard" element={<DashBoard />} />
            <Route path="/project" element={<ProjectOwner />} />
            <Route path="/tasktable" element={<TaskPage />} />
            <Route path="/addproject" element={<AddProject />} />
          <Route path="/addtask" element={<TaskForm />} />
          </Routes>
        </div>
        {/* right end  */}
      </div>
    </>
  );
}
export default App;
