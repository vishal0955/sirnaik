import React from "react";
// import "bootstrap/dist/css/bootstrap.min.css";

const TaskForm = () => {
  return (
    <div className="container mt-4">
      <h4>Add Task</h4>
      <div className="card p-4">
        <h5>Task Info</h5>
        <form>
          <div className="mb-3">
            <label className="form-label">Title <span className="text-danger">*</span></label>
            <input type="text" className="form-control" placeholder="Enter a task title" />
          </div>
          
          <div className="row">
            <div className="col-md-6 mb-3">
              <label className="form-label">Project</label>
              <select className="form-select">
                <option>--</option>
              </select>
            </div>
            <div className="col-md-6 mb-3">
              <label className="form-label">Task category</label>
              <div className="input-group">
                <select className="form-select">
                  <option>--</option>
                </select>
                <button className="btn btn-outline-secondary">Add</button>
              </div>
            </div>
          </div>
          
          <div className="row">
            <div className="col-md-6 mb-3">
              <label className="form-label">Start Date <span className="text-danger">*</span></label>
              <input type="date" className="form-control" defaultValue="2025-02-08" />
            </div>
            <div className="col-md-6 mb-3">
              <label className="form-label">Due Date <span className="text-danger">*</span></label>
              <input type="date" className="form-control" defaultValue="2025-02-08" />
            </div>
          </div>
          
          <div className="mb-3">
            <label className="form-label">Assigned To</label>
            <select className="form-select">
              <option>Nothing selected</option>
            </select>
          </div>
          
          <div className="mb-3">
            <label className="form-label">Description</label>
            <textarea className="form-control" rows="3"></textarea>
          </div>
          
          <div className="d-flex justify-content-between">
            <button type="submit" className="btn btn-primary">Save</button>
            <button type="button" className="btn btn-secondary">Save & Add More</button>
            <button type="button" className="btn btn-light">Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskForm;
